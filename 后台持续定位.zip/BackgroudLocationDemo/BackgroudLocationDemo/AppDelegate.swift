//
//  AppDelegate.swift
//  BackgroudLocationDemo
//
//  Created by GorCat on 2021/8/16.
//

import UIKit
import CoreLocation

@main
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    var manager = CLLocationManager()
    var window: UIWindow?


    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        manager.requestWhenInUseAuthorization()
        let window = UIWindow(frame: UIScreen.main.bounds)
        window.backgroundColor = .white
        window.rootViewController = ViewController()
        window.makeKeyAndVisible()
        self.window = window
        return true
    }

    
    func applicationDidEnterBackground(_ application: UIApplication) {

        //设置定位服务管理器代理
        manager.delegate = self
        //设置定位模式
        manager.desiredAccuracy = kCLLocationAccuracyBest
        //更新距离
        manager.distanceFilter = 0.1
        //发送授权申请
        manager.requestWhenInUseAuthorization()
        manager.allowsBackgroundLocationUpdates = true
        manager.startUpdatingLocation()
    }
    
    func applicationWillEnterForeground(_ application: UIApplication) {
        manager.stopUpdatingLocation()
    }

}

extension AppDelegate: CLLocationManagerDelegate {
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        print("=======后台运行")
        print(locations)
    }
}
